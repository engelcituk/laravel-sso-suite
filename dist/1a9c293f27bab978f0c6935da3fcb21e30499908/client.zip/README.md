# laravel-sso/client

Experimental Laravel SSO library.

Source: https://github.com/engelcituk/laravel-sso-suite/tree/1a9c293f27bab978f0c6935da3fcb21e30499908/packages/client

Installation: https://github.com/engelcituk/laravel-sso-suite/tree/composer#readme
