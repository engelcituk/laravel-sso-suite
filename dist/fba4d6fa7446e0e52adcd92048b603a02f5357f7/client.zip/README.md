# laravel-sso/client

Experimental Laravel SSO library.

Source: https://github.com/engelcituk/laravel-sso-suite/tree/fba4d6fa7446e0e52adcd92048b603a02f5357f7/packages/client

Installation: https://github.com/engelcituk/laravel-sso-suite/tree/composer#readme
