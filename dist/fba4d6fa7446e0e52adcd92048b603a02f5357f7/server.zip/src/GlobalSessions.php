<?php

declare(strict_types=1);

namespace LaravelSso\Server;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

final class GlobalSessions
{
    public function activeUser(string $subject): (Model&Authenticatable)|null
    {
        $guard = config('sso-server.guard');
        $provider = config('auth.guards.'.$guard.'.provider');
        $user = Auth::createUserProvider($provider)?->retrieveById($subject);
        $column = config('sso-server.active_column');

        return $user instanceof Model && ($column === null || (is_string($column) && $column !== '' && (bool) $user->getAttribute($column))) ? $user : null;
    }

    public function valid(string $sid, bool $touch = false, bool $lock = false): ?object
    {
        $deviceId = DB::table('sso_sessions')->where('sid', $sid)->value('device_id');
        if (is_string($deviceId) && ! app(DeviceSessions::class)->active($deviceId, $lock)) {
            return null;
        }
        $query = DB::table('sso_sessions')->where('sid', $sid);
        if ($lock) {
            if (DB::transactionLevel() === 0) {
                throw new \LogicException('A session lock requires an enclosing transaction.');
            }
            $query->lockForUpdate();
        }
        $session = $query->first();
        if (! $session || $session->revoked || $session->expires_at <= time()
            || $session->last_seen + config('sso-server.session_idle') <= time()
            || ! $this->activeUser($session->subject)) {
            return null;
        }
        if ($lock) {
            DB::table('sso_sessions')->where('sid', $sid)->update(['last_seen' => $session->last_seen]);
        }
        if ($touch) {
            DB::table('sso_sessions')->where('sid', $sid)->where('revoked', false)->update(['last_seen' => time()]);
            if (is_string($deviceId)) {
                DB::table('sso_devices')->where('id', $deviceId)->whereNull('revoked_at')->update(['last_seen' => time()]);
            }
        }

        return $session;
    }

    public function establish(Request $request, Authenticatable $user): object
    {
        $sid = $request->session()->get('sso.sid');
        if (is_string($sid) && ($session = $this->valid($sid, true))
            && $session->subject === (string) $user->getAuthIdentifier()) {
            return $session;
        }
        $sid = bin2hex(random_bytes(32));
        $now = time();
        $deviceId = $request->session()->get('sso.device_id');
        if (! is_string($deviceId)) {
            $deviceId = app(DeviceSessions::class)->register($request, $user)->id;
        }
        Transactions::run(function () use ($deviceId, $sid, $user, $request, $now): void {
            $device = app(DeviceSessions::class)->active($deviceId, true);
            abort_unless($device && $device->subject === (string) $user->getAuthIdentifier(), 403, 'The device is no longer active.');
            DB::table('sso_sessions')->insert([
                'sid' => $sid, 'subject' => (string) $user->getAuthIdentifier(), 'device_id' => $deviceId,
                'auth_time' => $request->session()->get('sso.auth_time', $now),
                'last_seen' => $now, 'expires_at' => min((int) $device->expires_at, $now + config('sso-server.session_max')), 'revoked' => false,
            ]);
            app(Audit::class)->record('session.created', ['sid' => $sid, 'subject' => (string) $user->getAuthIdentifier(), 'device' => $deviceId]);
        });
        $request->session()->put('sso.sid', $sid);

        return DB::table('sso_sessions')->where('sid', $sid)->first();
    }

    public function revoke(string $sid): void
    {
        $deviceId = DB::table('sso_sessions')->where('sid', $sid)->value('device_id');
        if (is_string($deviceId) && app(DeviceSessions::class)->revoke($deviceId)) {
            return;
        }
        $this->revokeSession($sid);
    }

    /** @internal DeviceSessions owns device-wide revocation and lock ordering. */
    public function revokeSession(string $sid): void
    {
        Transactions::run(function () use ($sid): void {
            $session = DB::table('sso_sessions')->where('sid', $sid)->lockForUpdate()->first();
            if (! $session) {
                return;
            }
            DB::table('sso_sessions')->where('sid', $sid)->update(['revoked' => true]);
            if (! $session->revoked) {
                app(Audit::class)->record('session.revoked', ['sid' => $sid, 'subject' => $session->subject]);
            }
            // Current locking read also sees bindings committed while a MySQL snapshot
            // was waiting for the session lock. Keep the same lock order as exchange.
            $bindings = DB::table('sso_token_sessions')->where('sid', $sid)->orderBy('token_id')->lockForUpdate()->get();
            $clients = $bindings->pluck('client_id')->unique();
            foreach ($clients as $clientId) {
                if (DB::table('sso_clients')->where('client_id', $clientId)->whereNotNull('backchannel_logout_uri')->exists()) {
                    DB::table('sso_logout_deliveries')->insertOrIgnore([
                        'id' => bin2hex(random_bytes(32)), 'sid' => $sid, 'client_id' => $clientId, 'next_attempt' => time(),
                    ]);
                }
            }
            $ids = $bindings->pluck('token_id');
            DB::table('oauth_access_tokens')->whereIn('id', $ids)->update(['revoked' => true]);
        });
    }

    public function revokeAll(string $subject): void
    {
        app(DeviceSessions::class)->revokeAll($subject);
    }
}
